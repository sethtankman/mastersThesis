"""
   Energy-based Logic Machines
   Son N. Tran
   sontn.fz@gmail.com
"""
class EBLM(object):
    
