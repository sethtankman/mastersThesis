"""
   (Deep) Neural Logic Networks
   Son N. Tran
   sontn.fz@gmail.com
"""
class NLN(object):
    def __init__(self,conf,dataset):
        self.conf = conf
        self.dataset = dataset

    def build_model(self):
        #### ---> RBM layer


        #### ---> Neural Net layers

    def run(self):
        
    
