function outp = minimum_energy(R,inp,indices)
% Son N. Tran
% R.r: vNum x number_of_rules --> (-1,0,1) matrix
% R.c: 1xnumber_of_rules      --> real positive values


end